

class Command:
    # ATTRIBUTES:
    # name (string): The name of the command
    
    Command(self, name): 
        self.name = name
        
    
    