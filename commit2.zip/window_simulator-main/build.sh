cp window_simulator.py stable
cp TCP_Server.py stable
cp LED_Strip.py stable
cp Modes.py stable
cp Remote_Receiver.py stable
cp Button.py stable
cp Alarm_Clock.py stable
